﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sports.Core
{
    public class TestListData
    {
        public int testId { get; set; }
        public string testType { get; set; }
        public string testDate { get; set; }
        public int count { get; set; }
    }
}
