﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace ChatModel.Core
{
    public class Comment
    {
        public int CommentId { get; set; }
        public int UserId { get; set; }
        public int MessageId { get; set; }
        [Required]
        public string Comments { get; set; }


    }
}
