﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChatModel.Core
{
    public class ViewComment
    {
        public int ViewCommentId { get; set; }
        public int CommentId { get; set; }
        public int MessageId { get; set; }
        public int UserId { get; set; }
        public string Comments { get; set; }

        public string Name { get; set; }
    }
}
