﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChatModel.Core
{
    public class Like
    {
        public int LikeId { get; set; }
        public int MessageId { get; set; }
        public int UserId { get; set; }
    }
}
