﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ChatModel.Core
{
    public class ViewLike
    {
        public int ViewLikeId { get; set; }
        public int LikeId { get; set; }
        public int MessageId { get; set; }
        public int UserId { get; set; }
        public string Name { get; set; }
    }
}
