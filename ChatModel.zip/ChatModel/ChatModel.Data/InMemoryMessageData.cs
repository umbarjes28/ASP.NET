﻿using ChatModel.Core;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ChatModel.Data
{
    public class InMemoryMessageData : InMemoryUserData, IMessageData
    {
        public List<Message> message;
        

        public InMemoryMessageData()
        {
            message = new List<Message>()
            {
                new Message{MessageId = 1, TextMessage="Hello",UserId = 1},
                 new Message{MessageId = 2, TextMessage="hii",UserId = 1}
            };
            
        }

       
        public Message Add(Message newMessage,int Id)
        {
            newMessage.MessageId = message.Max(u => u.MessageId) + 1;
            newMessage.UserId = Id;
            message.Add(newMessage);
            return newMessage;
        }

        public List<Post> GetAllMessage()
        {
            var query1 = message.Join(users,
                        m => m.UserId,
                        u => u.UserId,
                        (u, m) => new Post
                        {
                            UserId = u.UserId,
                            MessageId = u.MessageId,
                            Name = m.Name,
                            TextMessage = u.TextMessage
                        }).OrderBy(u =>u.MessageId).ToList();
            return query1;
        }

       
    }
}
