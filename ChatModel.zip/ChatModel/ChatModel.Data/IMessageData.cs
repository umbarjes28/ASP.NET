﻿using ChatModel.Core;
using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace ChatModel.Data
{
    public interface IMessageData 
    {
        List<Post> GetAllMessage();
        Message Add(Message message, int Id);
    }

    
}
