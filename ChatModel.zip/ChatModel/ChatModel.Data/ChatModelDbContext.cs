﻿using ChatModel.Core;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace ChatModel.Data
{
    public class ChatModelDbContext : DbContext
    {
        public DbSet<User> User { get; set; }
        public DbSet<Message> Message { get; set; }
        public DbSet<Comment> Comment { get; set; }
        public DbSet<Like> Like { get; set; }
        public DbSet<Post> Post { get; set; }
        public DbSet<ViewComment> ViewComment { get; set; }
        public DbSet<ViewLike> ViewLike { get; set; }

        public ChatModelDbContext(DbContextOptions<ChatModelDbContext> Options) : base(Options)
        {

        }
    }
}
