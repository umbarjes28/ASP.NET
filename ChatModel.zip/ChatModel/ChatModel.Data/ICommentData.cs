﻿using ChatModel.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ChatModel.Data
{
    public interface ICommentData
    {
        List<ViewComment> GetAllMessage(int MessageId);
        Comment Add(Comment comment, int MsgId,int UserId);
    }

    public class InMemoryCommentData : InMemoryUserData,ICommentData
    {
        public List<Comment> comment;


        public InMemoryCommentData()
        {
            comment = new List<Comment>()
            {
                new Comment{CommentId = 1, MessageId = 1, Comments="Hello",UserId = 1},
                 new Comment{CommentId = 2, MessageId = 2, Comments="hii",UserId = 1}
            };

        }


        public Comment Add(Comment newComment, int MsgId, int UserId)
        {
            newComment.MessageId = MsgId;
            newComment.UserId = UserId;
            newComment.CommentId = comment.Max(u => u.CommentId) + 1;
            comment.Add(newComment);
            return newComment;
        }

        public List<ViewComment> GetAllMessage(int MessageId)
        {
            var query1 = comment.Join(users,
                        m => m.UserId,
                        u => u.UserId,
                        (u, m) => new ViewComment
                        {
                            UserId = u.UserId,
                            MessageId = u.MessageId,
                            Name = m.Name,
                            Comments = u.Comments,
                            CommentId = u.CommentId
                        }).Where(u => u.MessageId == MessageId)
                        .OrderBy(u => u.MessageId).ToList();
            return query1;
        }
    }
}
