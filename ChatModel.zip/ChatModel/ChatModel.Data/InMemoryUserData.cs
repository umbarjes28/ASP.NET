﻿using ChatModel.Core;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ChatModel.Data
{
    public class InMemoryUserData : IUserData
    {
        public List<User> users;

        public InMemoryUserData()
        {
            users = new List<User>()
            {
                new User{ UserId = 1, Name = "Shweta"},
                new User{ UserId = 2, Name = "Sumit"}
            };
        }

        public User Add(User newUser)
        {
            users.Add(newUser);
            newUser.UserId = users.Max(u => u.UserId) + 1;
            return newUser;
        }

        public int commit()
        {
            return 0;
        }

        public IEnumerable<User> GetAll()
        {
            return from u in users
                   orderby u.Name
                   select u;
        }

        public User GetById(int UserId)
        {
            return users.SingleOrDefault(u => u.UserId == UserId);
        }

        public User Update(User User)
        {
            var user = users.SingleOrDefault(u => u.UserId == User.UserId);
            if(user != null)
            {
                user.Name = User.Name;
            }
            return user;
        }
    }


}
