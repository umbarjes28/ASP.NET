﻿using ChatModel.Core;
using System.Collections.Generic;
using System.Text;

namespace ChatModel.Data
{
    public interface IUserData
    {
        IEnumerable<User> GetAll();

        User GetById(int UserId);

        User Update(User User);

        User Add(User newUser);
        int commit();

    }


}
