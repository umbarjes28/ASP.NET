﻿using ChatModel.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ChatModel.Data
{
    public interface ILikeData
    {
        List<ViewLike> GetAllLike(int MessageId);
        Like Add(Like like, int MsgId, int UserId);

        int GetLikeCount(int MessageId);
    }

    public class InMemoryLikeData : InMemoryUserData, ILikeData
    {
        public List<Like> like;


        public InMemoryLikeData()
        {
            like = new List<Like>()
            {
                new Like{LikeId = 1, MessageId = 1, UserId = 1},
                 new Like{LikeId = 2, MessageId = 2, UserId = 1}
            };

        }


        public Like Add(Like newLike,int MsgId, int UserId)
        {
            newLike = new Like { MessageId = MsgId, UserId = UserId };
            newLike.LikeId = like.Max(u => u.LikeId) + 1;
            like.Add(newLike);
            return newLike;
        }

        public List<ViewLike> GetAllLike(int MessageId)
        {
            var query1 = like.Join(users,
                        m => m.UserId,
                        u => u.UserId,
                        (u, m) => new ViewLike
                        {
                            UserId = u.UserId,
                            MessageId = u.MessageId,
                            Name = m.Name,
                            LikeId = u.LikeId
                        }).Where(u => u.MessageId == MessageId)
                        .OrderBy(u => u.LikeId).ToList();
            return query1;
        }

        public int GetLikeCount(int MessageId)
        {
            return like.Count(m => m.MessageId == MessageId);
        }
    }
}
