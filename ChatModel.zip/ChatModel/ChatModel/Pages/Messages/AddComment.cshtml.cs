﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ChatModel.Core;
using ChatModel.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ChatModel.Pages.Messages
{
    public class AddCommentModel : PageModel
    {
        private readonly ICommentData commentData;
        [BindProperty]
        public Comment comment { get; set; }

        public AddCommentModel(ICommentData commentData)
        {
            this.commentData = commentData;
        }
        public IActionResult OnGet()
        {
            comment = new Comment();
            return Page();
        }

        public IActionResult OnPost(int MessageId,int UserId)
        {
            if (ModelState.IsValid)
            {
                commentData.Add(comment, MessageId, UserId);
                return RedirectToPage("./Details");
            }

            return Page();
        }
    }
}