﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ChatModel.Core;
using ChatModel.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ChatModel.Pages.Messages
{
    public class CommentModel : PageModel
    {
        private readonly ICommentData commentData;

        public Comment Comment { get; set; }
        public List<ViewComment> comments { get; set; }

        public CommentModel(ICommentData commentData)
        {
            this.commentData = commentData;
        }
        public IActionResult OnGet(int MessageId)
        {
            comments = commentData.GetAllMessage(MessageId);
            return Page();
        }

        public IActionResult OnPost()
        {
            Comment = new Comment();
            return Page();
        }
    }
}