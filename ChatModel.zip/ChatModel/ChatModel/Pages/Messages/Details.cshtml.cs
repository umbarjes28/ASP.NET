﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ChatModel.Core;
using ChatModel.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ChatModel.Pages.Messages
{
    public class DetailsModel : PageModel
    {
        private readonly IMessageData messageData;

        public List<Post> message { get; set; }
       
        public DetailsModel(IMessageData MessageData)
        {
            this.messageData = MessageData;
        }
        public IActionResult OnGet()
        {
            message = messageData.GetAllMessage();
            return Page();
        }

        public IActionResult OnPost()
        {
            message = messageData.GetAllMessage();
            return Page();
        }
    }
}