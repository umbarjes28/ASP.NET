﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ChatModel.Core;
using ChatModel.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ChatModel.Pages.Messages
{
    public class AddModel : PageModel
    {
        private readonly IMessageData messageData;
        [BindProperty]
        public Message message { get; set; }
      
        public AddModel(IMessageData messageData)
        {
            this.messageData = messageData;
        }
        public IActionResult OnGet(int UserId)
        {
            message = new Message();
            return Page();
        }

        public IActionResult OnPost(int UserId)
        {
            if(ModelState.IsValid)
            {
                messageData.Add(message, UserId);
                return RedirectToPage("./Details");
            }
           
            return Page();
        }
    }
}