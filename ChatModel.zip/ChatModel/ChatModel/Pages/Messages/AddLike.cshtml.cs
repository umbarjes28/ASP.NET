﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ChatModel.Core;
using ChatModel.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ChatModel.Pages.Messages
{
    public class AddLikeModel : PageModel
    {
        private readonly ILikeData likeData;
        [BindProperty]
        public Like like { get; set; }
        public int Count { get; set; }
        public List<ViewLike> list { get; set; }

        public AddLikeModel(ILikeData likeData)
        {
            this.likeData = likeData;
        }
        public IActionResult OnGet(int MessageId, int UserId)
        {
           
            likeData.Add(like, MessageId, UserId);
            Count = likeData.GetLikeCount(MessageId);
            list = likeData.GetAllLike(MessageId);
            return Page();
        }

        public IActionResult OnPost(int MessageId, int UserId)
        {
            likeData.Add(like, MessageId, UserId);
            Count = likeData.GetLikeCount(MessageId);
            list = likeData.GetAllLike(MessageId);
            return Page();
        }
    }
}