﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ChatModel.Core;
using ChatModel.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ChatModel.Pages.Users
{
    public class EditModel : PageModel
    {
        private readonly IUserData userData;

        [BindProperty]
        public User user { get; set; }
            
        public EditModel(IUserData userData)
        {
            this.userData = userData;
        }
        public IActionResult OnGet(int? UserId)
        {
            if(UserId.HasValue)
            {
                user = userData.GetById(UserId.Value);
            }
            else
            {
                user = new User();
            }
            if(user == null)
            {
                return RedirectToPage("/NotFound");
            }

            return Page();
        }
        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                if (user.UserId > 0)
                {
                    userData.Update(user);
                }
                else
                {
                    userData.Add(user);
                }
                return RedirectToPage("./List");
            }
            return Page();
        }
    }
}